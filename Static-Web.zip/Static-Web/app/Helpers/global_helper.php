<?php


use App\Models\metadata;

function get_meta_value($meta_key)
{
    $data = metadata::where('meta_key', $meta_key)->first();

    if ($data)
    {
        return $data->meta_value;
    }
}

function set_about_name($name)
{
    $arr = explode(" ", $name);
    $last = end($arr);
    $last_use = "<span class='text-primary'>$last</span>";
    array_pop($arr);
    $first = implode(" ", $arr);

    return $first . " " . $last_use;
}

function set_list_award($content)
{
    $content = str_replace("<ul>", '<ul class="fa-ul mb-0">', $content);
    $content = str_replace("<li>", '<li><span class="fa-li"><i class="fas fa-trophy text-warning"></i></span>', $content);

    return $content;
}

function set_list_workflow($content)
{
    $content = str_replace("<ul>", '<ul class="fa-ul mb-0">', $content);
    $content = str_replace("<li>", '<li><span class="fa-li"><i class="fas fa-check"></i></span>', $content);

    return $content;
}

function set_acc_linkn($content)
{
    $arr = explode(" ", $content);
    $last = end($arr);
    array_pop($arr);
    $first = implode(" ", $arr);

    return $first . "-" . $last;
}

function set_acc_fb($content)
{
    $first = $content;
    $last = $content;

    return $first . "." . $last;
}