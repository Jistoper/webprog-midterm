<?php

namespace App\Http\Controllers;

use App\Models\history;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class eduController extends Controller
{
    function __construct()
    {
        $this->_type = 'education';
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = history::where('type', $this->_type)->orderBy('end_date', 'desc')->get();
        return view('dashboard.edu.index')->with('data', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.edu.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Session::flash('title', $request->title);
        Session::flash('info1', $request->info1);
        Session::flash('info2', $request->info2);
        Session::flash('info3', $request->info3);
        Session::flash('start_date', $request->start_date);
        Session::flash('end_date', $request->end_date);

        $request->validate(
            [
                'title' => 'required',
                'info1' => 'required',
                'start_date' => 'required',
            ],
            [
                'title.required' => 'University must not be empty',
                'info1.required' => 'Faculty must not be empty',
                'start_date.required' => 'Start Date must not be empty',
            ]
        );

        $data = [
            'title' => $request->title,
            'info1' => $request->info1,
            'info2' => $request->info2,
            'info3' => $request->info3,
            'type' => $this->_type,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date
        ];
        
        history::create($data);
        return redirect()->route('education.index')->with('success', 'Data Succesfully Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = history::where('id', $id)->where('type', $this->_type)->first();
        return view('dashboard.edu.edit')->with('data', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate(
            [
                'title' => 'required',
                'info1' => 'required',
                'start_date' => 'required',
            ],
            [
                'title.required' => 'University must not be empty',
                'info1.required' => 'Faculty must not be empty',
                'start_date.required' => 'Start Date must not be empty',
            ]
        );

        $data = [
            'title' => $request->title,
            'info1' => $request->info1,
            'info2' => $request->info2,
            'info3' => $request->info3,
            'type' => $this->_type,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date
        ];
        
        history::where('id', $id)->update($data);
        return redirect()->route('education.index')->with('success', 'Data Succesfully Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        history::where('id', $id)->where('type', $this->_type)->delete();
        return redirect()->route('education.index')->with('success', 'Data Succesfully Deleted');
    }
}
