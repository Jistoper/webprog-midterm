<?php

namespace App\Http\Controllers;

use App\Models\metadata;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class profileController extends Controller
{
    function index()
    {
        return view('dashboard.profile.index');
    }

    function update(Request $request)
    {
        $request->validate(
            [
                '_photo' => 'mimes:jpeg, jpg, png, gif',
                '_email' => 'required|email',
            ],
            [
                '_photo.mimes' => 'The allowed file extension for photos are .jpeg, .jpg, .png, .gif',
                '_email.required' => 'Email must not be empty',
                '_email.email' => 'Email format invalid'
            ]
        );

        if ($request->hasFile('_photo'))
        {
            $photo_file = $request->file('_photo');
            $photo_ext = $photo_file->extension();
            $photo_new = date('ymdhis') . ".$photo_ext";
            $photo_file->move(public_path('photos'), $photo_new);

            $photo_old = get_meta_value('_photo');
            File::delete(public_path('photos') . "/" . $photo_old);

            metadata::updateOrCreate(['meta_key' => '_photo'], ['meta_value' => $photo_new]);
        }

        metadata::updateOrCreate(['meta_key' => '_email'], ['meta_value' => $request->_email]);
        metadata::updateOrCreate(['meta_key' => '_city'], ['meta_value' => $request->_city]);
        metadata::updateOrCreate(['meta_key' => '_province'], ['meta_value' => $request->_province]);
        metadata::updateOrCreate(['meta_key' => '_phone'], ['meta_value' => $request->_phone]);
        metadata::updateOrCreate(['meta_key' => '_fb'], ['meta_value' => $request->_fb]);
        metadata::updateOrCreate(['meta_key' => '_twt'], ['meta_value' => $request->_twt]);
        metadata::updateOrCreate(['meta_key' => '_linkn'], ['meta_value' => $request->_linkn]);
        metadata::updateOrCreate(['meta_key' => '_ghub'], ['meta_value' => $request->_ghub]);

        return redirect()->route('profile.index')->with('success', 'Profile Succesfully Updated');
    }
}
