<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestControl extends Controller
{
    function index ()
    {
        return '<h1>Ini dari controller</h1>';
    }
    function detail ($id)
    {
        if ($id == 1)
            return "<h1>Nama mahasiswa/i : Ani</h1><h1>NIM : $id</h1>";
        else if ($id == 2)
            return "<h1>Saya mahasiswa/i : Tono</h1><h1>NIM : $id</h1>";
        else if ($id == 3)
            return "<h1>Saya mahasiswa/i : Deny</h1><h1>NIM : $id</h1>";
        else if ($id == 4)
            return "<h1>Saya mahasiswa/i : Humam</h1><h1>NIM : $id</h1>";
    }
}
