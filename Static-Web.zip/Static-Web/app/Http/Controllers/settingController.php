<?php

namespace App\Http\Controllers;

use App\Models\page;
use App\Models\metadata;
use Illuminate\Http\Request;

class settingController extends Controller
{
    function index()
    {
        $pagedata = page::orderBy('title', 'asc')->get();
        return view('dashboard.pagesetting.index')->with('pagedata', $pagedata);
    }

    function update(Request $request)
    {
        metadata::updateOrCreate(
            ['meta_key'=>'_page_about'],
            ['meta_value'=>$request->_page_about]
        );
        metadata::updateOrCreate(
            ['meta_key'=>'_page_interest'],
            ['meta_value'=>$request->_page_interest]
        );
        metadata::updateOrCreate(
            ['meta_key'=>'_page_award'],
            ['meta_value'=>$request->_page_award]
        );
        return redirect()->route('pageset.index')->with('success', 'Setting Succesfully Updated');
    }
}
