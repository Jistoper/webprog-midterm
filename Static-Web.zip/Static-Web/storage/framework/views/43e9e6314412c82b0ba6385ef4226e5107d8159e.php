

<?php $__env->startSection('pages'); ?>
    <form action="<?php echo e(route('pageset.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label class="col-sm-2">About</label>
            <div class="com-sm-6">
                <select class="form-control form-control-sm" name="_page_about">
                    <option value="">--choose--</option>
                    <?php $__currentLoopData = $pagedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php echo e(get_meta_value('_page_about') == $item->id ? 'selected' : ''); ?>><?php echo e($item->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2">Interest</label>
            <div class="com-sm-6">
                <select class="form-control form-control-sm" name="_page_interest">
                    <option value="">--choose--</option>
                    <?php $__currentLoopData = $pagedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php echo e(get_meta_value('_page_interest') == $item->id ? 'selected' : ''); ?>><?php echo e($item->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-2">Award</label>
            <div class="com-sm-6">
                <select class="form-control form-control-sm" name="_page_award">
                    <option value="">--choose--</option>
                    <?php $__currentLoopData = $pagedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php echo e(get_meta_value('_page_award') == $item->id ? 'selected' : ''); ?>><?php echo e($item->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <button class="btn btn-primary" name="save" type="submit">
            <font color="white">Save</font>
        </button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 4\Mid\Web Prog\Static-Web\resources\views/dashboard/pagesetting/index.blade.php ENDPATH**/ ?>