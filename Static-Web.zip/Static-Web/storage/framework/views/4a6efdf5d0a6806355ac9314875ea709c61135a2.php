

<?php $__env->startSection('pages'); ?>
    <div class="pb-3">
        <a href="<?php echo e(route('education.index')); ?>" class="btn btn-secondary" >
            <font color="white" style:"text-align: left">< Back</font>
        </a>
    </div>
    <form action="<?php echo e(route('education.update', $data->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <tb>
                <p style="text-align: left">
                    <font color="red" size=2>* required</font>
                </p>
                <p style="text-align: right">
                    <font color="red" size=2>**</font><font size=2> May be empty</font>
                </p>
            </tb>
        </div>
        <div class="mb-3">
            <label for="title" class="form-label">University<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm" name="title" id="title" aria-describedby="helpId" placeholder="University Name" value="<?php echo e($data->title); ?>">
        </div>
        <div class="mb-3">
            <label for="info1" class="form-label">Faculty<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm" name="info1" id="info1" aria-describedby="helpId" placeholder="Faculty Name" value="<?php echo e($data->info1); ?>">
        </div>
        <div class="mb-3">
            <label for="info2" class="form-label">Major<font color="red"> **</font></label>
            <input type="text" class="form-control form-control-sm" name="info2" id="info2" aria-describedby="helpId" placeholder="Major" value="<?php echo e($data->info2); ?>">
        </div>
        <div class="mb-3">
            <label for="info3" class="form-label">GPA<font color="red"> **</font></label>
            <input type="text" class="form-control form-control-sm" name="info3" id="info3" aria-describedby="helpId" placeholder="Your GPA" value="<?php echo e($data->info3); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Date<font color="red"> *</font></label>
            <div class="row">
                <div class="col-auto">From</div>
                <div class="col-auto">
                    <input type="date" class="form-control form-control-sm" name="start_date" placeholder="Start Date" value="<?php echo e($data->start_date); ?>">
                </div>
                <div class="col-auto">to<font color="red"> **</font></div>
                <div class="col-auto">
                    <input type="date" class="form-control form-control-sm" name="end_date" placeholder="End Date" value="<?php echo e($data->end_date); ?>">
                </div>
            </div>
        </div>
        <button class="btn btn-primary" name="save" type="submit">
            <font color="white">Save</font>
        </button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 4\Mid\Web Prog\Static-Web\resources\views/dashboard/edu/edit.blade.php ENDPATH**/ ?>