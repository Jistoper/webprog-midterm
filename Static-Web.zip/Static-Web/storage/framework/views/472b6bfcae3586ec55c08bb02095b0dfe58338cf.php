

<?php $__env->startSection('pages'); ?>
    <div class="pb-3">
        <a href="<?php echo e(route('pages.index')); ?>" class="btn btn-secondary" >
            <font color="white" style:"text-align: left">< Back</font>
        </a>
    </div>
    <form action="<?php echo e(route('pages.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <tb>
                <p style="text-align: left">
                    <font color="red" size=2>* required</font>
                </p>
            </tb>
        </div>
        <div class="mb-3">
            <label for="title" class="form-label">Title<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm" name="title" id="title" aria-describedby="helpId" placeholder="Page Title" value="<?php echo e(Session::get('title')); ?>">
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">Content<font color="red"> *</font></label>
            <textarea class="form-control summernote" name="content" id="content" rows="5" placeholder="Page Content"><?php echo e(Session::get('content')); ?></textarea>
        </div>
        <button class="btn btn-primary" name="save" type="submit">
            <font color="white">Save</font>
        </button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 4\Mid\Web Prog\Static-Web\resources\views/dashboard/pages/create.blade.php ENDPATH**/ ?>