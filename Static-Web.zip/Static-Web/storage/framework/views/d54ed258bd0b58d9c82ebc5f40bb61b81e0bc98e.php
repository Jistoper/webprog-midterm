

<?php $__env->startSection('pages'); ?>
    <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <tb>
                <p style="text-align: left">
                    <font color="red" size=2>* required</font>
                </p>
            </tb>
        </div>
        <div class="row justify-content-between">
            <div class="col-5">
                <h3>Profile</h3>
                <?php if(get_meta_value('_photo')): ?>
                    <img style="max-width:100px;max-height:100px" src="<?php echo e(asset('photos')."/".get_meta_value('_photo')); ?>">
                <?php endif; ?>
                <div class="mb-3">
                    <label for="_photo" class="form-label">Photo<font color="red"> *</font></label>
                    <input type="file" class="form-control form-control-sm" name="_photo" id="_photo">
                </div>
                <div class="mb-3">
                    <label for="_city" class="form-label">City<font color="red"> *</font></label>
                    <input type="text" class="form-control form-control-sm" name="_city" id="_city" value="<?php echo e(get_meta_value('_city')); ?>">
                </div>
                <div class="mb-3">
                    <label for="_province" class="form-label">Province<font color="red"> *</font></label>
                    <input type="text" class="form-control form-control-sm" name="_province" id="_province" value="<?php echo e(get_meta_value('_province')); ?>">
                </div>
                <div class="mb-3">
                    <label for="_phone" class="form-label">Phone Number<font color="red"> *</font></label>
                    <input type="text" class="form-control form-control-sm" name="_phone" id="_phone" value="<?php echo e(get_meta_value('_phone')); ?>">
                </div>
                <div class="mb-3">
                    <label for="_email" class="form-label">Email<font color="red"> *</font></label>
                    <input type="text" class="form-control form-control-sm" name="_email" id="_email" value="<?php echo e(get_meta_value('_email')); ?>">
                </div>
            </div>
            <div class="col-5">
                <h3>Social Media Account</h3>
                <div class="mb-3">
                    <label for="_fb" class="form-label">Facebook<font color="red"> *</font></label>
                    <input type="text" class="form-control form-control-sm" name="_fb" id="_fb" value="<?php echo e(get_meta_value('_fb')); ?>">
                </div>
                <div class="mb-3">
                    <label for="_twt" class="form-label">Twitter<font color="red"> *</font></label>
                    <input type="text" class="form-control form-control-sm" name="_twt" id="_twt" value="<?php echo e(get_meta_value('_twt')); ?>">
                </div>
                <div class="mb-3">
                    <label for="_linkn" class="form-label">LinkedIn<font color="red"> *</font></label>
                    <input type="text" class="form-control form-control-sm" name="_linkn" id="_linkn" value="<?php echo e(get_meta_value('_linkn')); ?>">
                </div>
                <div class="mb-3">
                    <label for="_ghub" class="form-label">GitHub<font color="red"> *</font></label>
                    <input type="text" class="form-control form-control-sm" name="_ghub" id="_ghub" value="<?php echo e(get_meta_value('_ghub')); ?>">
                </div>
            </div>
        </div>
        <button class="btn btn-primary" name="save" type="submit">
            <font color="white">Save</font>
        </button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Semester 4\Mid\Web Prog\Static-Web\resources\views/dashboard/profile/index.blade.php ENDPATH**/ ?>