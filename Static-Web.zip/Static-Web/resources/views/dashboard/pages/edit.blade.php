@extends('dashboard.layout')

@section('pages')
    <div class="pb-3">
        <a href="{{ route('pages.index') }}" class="btn btn-secondary" >
            <font color="white" style:"text-align: left">< Back</font>
        </a>
    </div>
    <form action="{{ route('pages.update', $data->id) }}" method="POST">
        @csrf
        @method('put')
        <div>
            <tb>
                <p style="text-align: left">
                    <font color="red" size=2>* required</font>
                </p>
            </tb>
        </div>
        <div class="mb-3">
            <label for="title" class="form-label">Title<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm" name="title" id="title" aria-describedby="helpId" placeholder="Page Title" value="{{ $data->title }}">
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">Content<font color="red"> *</font></label>
            <textarea class="form-control summernote" name="content" id="content" rows="5" placeholder="Page Content">{{ $data->content }}</textarea>
        </div>
        <button class="btn btn-primary" name="save" type="submit">
            <font color="white">Save</font>
        </button>
    </form>
@endsection