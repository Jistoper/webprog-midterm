@extends('dashboard.layout')

@section('pages')
    <div class="pb-3">
        <a href="{{ route('experience.index') }}" class="btn btn-secondary" >
            <font color="white" style:"text-align: left">< Back</font>
        </a>
    </div>
    <form action="{{ route('experience.store') }}" method="POST">
        @csrf
        <div>
            <tb>
                <p style="text-align: left">
                    <font color="red" size=2>* required</font>
                </p>
            </tb>
        </div>
        <div class="mb-3">
            <label for="title" class="form-label">Position<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm" name="title" id="title" aria-describedby="helpId" placeholder="Job Position" value="{{ Session::get('title') }}">
        </div>
        <div class="mb-3">
            <label for="info1" class="form-label">Company<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm" name="info1" id="info1" aria-describedby="helpId" placeholder="Company Name" value="{{ Session::get('info1') }}">
        </div>
        <div class="mb-3">
            <label class="form-label">Date<font color="red"> *</font></label>
            <div class="row">
                <div class="col-auto">From</div>
                <div class="col-auto">
                    <input type="date" class="form-control form-control-sm" name="start_date" placeholder="Start Date" value="{{ Session::get('start_date') }}">
                </div>
                <div class="col-auto">to<font color="red"> **</font></div>
                <div class="col-auto">
                    <input type="date" class="form-control form-control-sm" name="end_date" placeholder="End Date" value="{{ Session::get('end_date') }}">
                </div>
            </div>
            <tb>
                <p style="text-align: right">
                    <font color="red" size=2>**</font><font size=2> May be empty</font>
                </p>
            </tb>
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">Description<font color="red"> *</font></label>
            <textarea class="form-control summernote" name="content" id="content" rows="5" placeholder="Page Content">{{ Session::get('content') }}</textarea>
        </div>
        <button class="btn btn-primary" name="save" type="submit">
            <font color="white">Save</font>
        </button>
    </form>
@endsection