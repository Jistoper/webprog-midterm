@extends('dashboard.layout')

@section('pages')
    <div class="pb-3">
        <a href="{{ route('education.index') }}" class="btn btn-secondary" >
            <font color="white" style:"text-align: left">< Back</font>
        </a>
    </div>
    <form action="{{ route('education.store') }}" method="POST">
        @csrf
        <div>
            <tb>
                <p style="text-align: left">
                    <font color="red" size=2>* required</font>
                </p>
                <p style="text-align: left">
                    <font color="red" size=2>**</font><font size=2> May be empty</font>
                </p>
            </tb>
        </div>
        <div class="mb-3">
            <label for="title" class="form-label">University<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm" name="title" id="title" aria-describedby="helpId" placeholder="University Name" value="{{ Session::get('title') }}">
        </div>
        <div class="mb-3">
            <label for="info1" class="form-label">Faculty<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm" name="info1" id="info1" aria-describedby="helpId" placeholder="Faculty Name" value="{{ Session::get('info1') }}">
        </div>
        <div class="mb-3">
            <label for="info2" class="form-label">Major<font color="red"> **</font></label>
            <input type="text" class="form-control form-control-sm" name="info2" id="info2" aria-describedby="helpId" placeholder="Major" value="{{ Session::get('info2') }}">
        </div>
        <div class="mb-3">
            <label for="info3" class="form-label">GPA<font color="red"> **</font></label>
            <input type="text" class="form-control form-control-sm" name="info3" id="info3" aria-describedby="helpId" placeholder="Your GPA" value="{{ Session::get('info3') }}">
        </div>
        <div class="mb-3">
            <label class="form-label">Date<font color="red"> *</font></label>
            <div class="row">
                <div class="col-auto">From</div>
                <div class="col-auto">
                    <input type="date" class="form-control form-control-sm" name="start_date" placeholder="Start Date" value="{{ Session::get('start_date') }}">
                </div>
                <div class="col-auto">to<font color="red"> **</font></div>
                <div class="col-auto">
                    <input type="date" class="form-control form-control-sm" name="end_date" placeholder="End Date" value="{{ Session::get('end_date') }}">
                </div>
            </div>
        </div>
        <button class="btn btn-primary" name="save" type="submit">
            <font color="white">Save</font>
        </button>
    </form>
@endsection