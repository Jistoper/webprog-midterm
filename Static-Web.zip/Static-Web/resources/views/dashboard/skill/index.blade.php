@extends('dashboard.layout')

@section('pages')
    <form action="{{ route('skill.update') }}" method="POST">
        @csrf
        <div>
            <tb>
                <p style="text-align: left">
                    <font color="red" size=2>* required</font>
                </p>
            </tb>
        </div>
        <div class="mb-3">
            <label for="title" class="form-label">Programming Languages & Tools<font color="red"> *</font></label>
            <input type="text" class="form-control form-control-sm skill" name="_language" id="title" aria-describedby="helpId" placeholder="Programming Language & Tools" value="{{ get_meta_value('_language') }}">
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">Workflow<font color="red"> *</font></label>
            <textarea class="form-control summernote" name="_workflow" id="content" rows="5">{{ get_meta_value('_workflow') }}</textarea>
        </div>
        <button class="btn btn-primary" name="save" type="submit">
            <font color="white">Save</font>
        </button>
    </form>
@endsection

@push('child-scripts')
<script>
    $(document).ready(function() {
        $('.skill').tokenfield({
            autocomplete: {
                source: [{!! $skill !!}],
                delay: 100
            },
            showAutocompleteOnFocus: true
        });
    });
  </script>
@endpush